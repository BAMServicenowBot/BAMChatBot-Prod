﻿namespace BamChatBot.Services
{
	internal class Incident
	{
		public string Sys_Id { get; set; }
		public string Number { get; set; }
	}
}