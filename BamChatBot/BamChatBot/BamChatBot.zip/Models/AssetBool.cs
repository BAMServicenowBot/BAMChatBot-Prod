﻿namespace BamChatBot.Models
{
    public class AssetBool
    {
        public bool value { get; set; }
        public bool required { get; set; }
    }
}