﻿namespace BamChatBot.Models
{
    public class AssetInt
    {
        public double value { get; set; }
        public bool required { get; set; }
    }
}