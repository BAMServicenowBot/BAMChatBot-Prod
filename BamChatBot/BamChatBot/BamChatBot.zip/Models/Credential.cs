﻿namespace BamChatBot.Models
{
    public class Credential
    {
        public string value { get; set; }
        public bool required { get; set; }
    }
}