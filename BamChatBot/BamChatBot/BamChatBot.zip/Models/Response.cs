﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BamChatBot.Models
{
    public class Response
    {
        public string Result { get; set; }
        public int Length { get; set; }
    }
}
