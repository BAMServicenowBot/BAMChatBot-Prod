﻿namespace BamChatBot.Models
{
    public class UOU
    {
        public string u_id { get; set; }
    }
}