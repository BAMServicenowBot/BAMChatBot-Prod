﻿namespace BamChatBot.Models
{
    public class AssetString
    {
        public string value { get; set; }
        public bool required { get; set; }
    }
}